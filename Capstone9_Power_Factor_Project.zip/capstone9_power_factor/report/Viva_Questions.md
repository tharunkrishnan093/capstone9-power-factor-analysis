# Viva Questions and Short Answers

1. **What is power factor?** Active power divided by apparent power, PF = P/S.
2. **Why is power factor important?** It indicates how effectively apparent power is converted into useful active power; low PF can increase current for a given active-power demand.
3. **How did you calculate PF?** For the simulated single-phase setup, PF = P/(V×I).
4. **Why use thresholds?** To convert a continuous measurement into interpretable classes for flagging and reporting.
5. **Are the thresholds universal?** No. They are transparent educational assumptions for this project.
6. **Why Random Forest?** It captures nonlinear feature interactions and is a robust tabular-data baseline.
7. **What is data leakage?** When information unavailable at prediction time or directly encoding the target enters training features. PF was excluded from the feature list.
8. **Why split train and test data?** To evaluate on data not used to fit the model.
9. **What does accuracy mean?** The proportion of held-out samples classified correctly; it should be considered alongside class-wise precision and recall.
10. **What are the limitations?** Synthetic data, simplified single-phase assumptions, and limited evidence of generalization to real electrical systems.
11. **Why do we need a dashboard?** To make trends, class distributions, and flagged intervals accessible to a user.
12. **Can this directly control a capacitor bank?** No. This is an educational analytics tool, not a validated protection/control system.
