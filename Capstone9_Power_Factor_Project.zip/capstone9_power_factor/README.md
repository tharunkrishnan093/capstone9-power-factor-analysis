# Capstone 9 — AI-Based Power Factor Pattern Analysis and Classification

A beginner-friendly, reproducible EEE capstone using **synthetic single-phase electrical readings**. It includes data cleaning, exploratory analysis, a Random Forest classifier, evaluation, and a Streamlit dashboard.

## What is included
- `data/simulated_power_factor_readings.csv` — 6,003 rows including a few deliberate duplicate rows and missing sensor cells for preprocessing practice.
- `src/generate_dataset.py` — regenerates the synthetic dataset (seeded).
- `src/train_model.py` — cleans data, calculates power factor, trains/evaluates the model, and saves the model.
- `app.py` — Streamlit dashboard for trends and interval classification.
- `models/power_factor_classifier.joblib` — trained model.
- `outputs/` — EDA plots and sample held-out predictions.
- `report/Capstone9_Project_Report.docx` — editable project report.
- `report/Capstone9_Presentation.pptx` — editable presentation.
- `requirements.txt` — Python dependencies.

## Quick start (Python 3.10+ recommended)
1. Extract the ZIP.
2. Open a terminal in the extracted folder.
3. Create a virtual environment (optional but recommended):
   - Windows: `python -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Run the dashboard: `streamlit run app.py`
6. To retrain the model: `python src/train_model.py`

## Electrical assumptions
- Single-phase approximation: apparent power S = V × I.
- Power factor PF = P / S, clipped to [0, 1] for this synthetic dataset.
- Reactive power is simulated as Q = sqrt(S² − P²) for positive inductive loads.
- PF classes: `Low` if PF < 0.80; `Moderate` if 0.80 ≤ PF < 0.90; `Good` if PF ≥ 0.90. These are transparent project-defined bands for this demonstration, not universal legal or utility thresholds.
- Data are synthetic, not real measurements and not suitable for equipment design, billing, protection, or safety decisions.
- Model features intentionally exclude `power_factor` and `pf_class` to avoid direct target leakage. Since P, Q, V, and I are physically related, strong scores should not be interpreted as proof of generalization to real installations.

## Current baseline result
Held-out test accuracy: **0.938**. See `outputs/classification_report.txt` for class-wise metrics. Scores are from simulated data and may be optimistic relative to real field data.

## Dataset columns
- `timestamp`: synthetic 15-minute timestamp.
- `voltage_V`: RMS voltage (V).
- `current_A`: RMS current (A).
- `active_power_W`: active power P (W).
- `reactive_power_var`: reactive power Q (var).
- `load_level`: simulated normalized load index (0–1).
- `hour`: hour of day (0–24).
- `day_of_week`: Monday=0 through Sunday=6.
- `simulated_load_type`: synthetic load category used only to generate data; excluded from model features.
- `apparent_power_VA`: generated V×I estimate.
- `power_factor`: generated P/(V×I) target reference; recalculate from raw readings during training.
- `pf_class`: generated class label; retraining script recomputes it after cleaning.

## Viva-ready explanation
1. What is power factor? The ratio of real/active power to apparent power, PF = P/S.
2. Why classify? To flag intervals that may warrant inspection or further analysis.
3. Why Random Forest? It handles nonlinear interactions and mixed-scale tabular features with little preprocessing.
4. Why held-out test data? To estimate performance on unseen samples.
5. Main limitation? Synthetic data can encode artificial patterns; validation on authorized real measurements is needed before real-world use.

## Safety
Use public/simulated data or authorized low-voltage educational measurements only. Do not connect an experimental compensation circuit to mains. Any compensation discussion should remain mathematical/simulation-only and be reviewed by a qualified electrical engineer.
