from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Power Factor Pattern Analysis", page_icon="⚡", layout="wide")
st.title("AI-Based Power Factor Pattern Analysis and Classification")
st.caption("Capstone 9 | Synthetic educational data — not for electrical safety or equipment decisions")

DATA_PATH = Path("data/simulated_power_factor_readings.csv")
MODEL_PATH = Path("models/power_factor_classifier.joblib")
FEATURES = ["voltage_V","current_A","active_power_W","reactive_power_var","load_level","hour","day_of_week"]

@st.cache_data
def load_data():
    df = pd.read_csv(DATA_PATH)
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = df.drop_duplicates().copy()
    for c in FEATURES:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["power_factor"] = df["active_power_W"] / (df["voltage_V"]*df["current_A"])
    df["power_factor"] = df["power_factor"].replace([np.inf,-np.inf],np.nan).clip(0,1)
    df["power_factor"] = df["power_factor"].fillna(df["power_factor"].median())
    df["pf_class"] = np.where(df["power_factor"]<0.80,"Low",
                      np.where(df["power_factor"]<0.90,"Moderate","Good"))
    return df

df = load_data()
if not MODEL_PATH.exists():
    st.error("Model file not found. Run `python src/train_model.py` from the project folder.")
    st.stop()
model = joblib.load(MODEL_PATH)

with st.sidebar:
    st.header("Filters")
    min_date = df["timestamp"].min().date()
    max_date = df["timestamp"].max().date()
    date_range = st.date_input("Date range", value=(min_date,max_date), min_value=min_date, max_value=max_date)
    chosen_classes = st.multiselect("Power-factor classes", ["Low","Moderate","Good"], default=["Low","Moderate","Good"])
    st.markdown("---")
    st.markdown("**Class thresholds used**")
    st.write("Low: PF < 0.80")
    st.write("Moderate: 0.80 ≤ PF < 0.90")
    st.write("Good: PF ≥ 0.90")
    st.caption("Thresholds are project assumptions, not universal regulatory limits.")

if isinstance(date_range, tuple) and len(date_range)==2:
    dff = df[df["timestamp"].dt.date.between(date_range[0],date_range[1])]
else:
    dff = df.copy()
dff = dff[dff["pf_class"].isin(chosen_classes)]

c1,c2,c3,c4 = st.columns(4)
c1.metric("Intervals", f"{len(dff):,}")
c2.metric("Mean power factor", f"{dff['power_factor'].mean():.3f}" if len(dff) else "N/A")
c3.metric("Low-PF intervals", f"{(dff['pf_class']=='Low').sum():,}")
c4.metric("Missing cells in raw source", f"{pd.read_csv(DATA_PATH).isna().sum().sum():,}")

st.subheader("Power-factor trend")
if len(dff):
    trend = dff.set_index("timestamp")["power_factor"].resample("H").mean().dropna()
    st.line_chart(trend)
    st.subheader("Active and reactive power")
    power = dff.set_index("timestamp")[["active_power_W","reactive_power_var"]].resample("H").mean().dropna()
    st.line_chart(power)
    st.subheader("Class distribution")
    st.bar_chart(dff["pf_class"].value_counts().reindex(["Low","Moderate","Good"]).fillna(0))
else:
    st.info("No intervals match the selected filters.")

st.subheader("Classify a sample operating interval")
with st.form("predict_form"):
    a,b,c = st.columns(3)
    voltage = a.number_input("Voltage (V)", min_value=1.0, max_value=500.0, value=230.0, step=1.0)
    current = b.number_input("Current (A)", min_value=0.01, max_value=100.0, value=8.0, step=0.1)
    active = c.number_input("Active power (W)", min_value=0.0, max_value=50000.0, value=1500.0, step=50.0)
    d,e,f = st.columns(3)
    reactive = d.number_input("Reactive power (var)", min_value=0.0, max_value=50000.0, value=900.0, step=50.0)
    load = e.slider("Normalized load level", 0.0, 1.0, 0.55, 0.05)
    hour = f.slider("Hour of day", 0.0, 23.75, 12.0, 0.25)
    dow = st.selectbox("Day of week", options=list(range(7)), format_func=lambda x:["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"][x])
    submitted = st.form_submit_button("Classify interval")
if submitted:
    row = pd.DataFrame([[voltage,current,active,reactive,load,hour,dow]], columns=FEATURES)
    prediction = model.predict(row)[0]
    measured_pf = active / max(voltage*current,1e-9)
    st.write(f"**Model classification:** {prediction}")
    st.write(f"**Calculated PF estimate from entered values:** {measured_pf:.3f}")
    if measured_pf < 0.80:
        st.warning("The calculated PF falls in the project-defined Low band.")
    elif measured_pf < 0.90:
        st.info("The calculated PF falls in the project-defined Moderate band.")
    else:
        st.success("The calculated PF falls in the project-defined Good band.")
    st.caption("The calculated PF and ML prediction can differ because the model is an approximation. For this dataset, PF = P/(V×I) is a single-phase approximation.")

st.subheader("Flagged intervals")
threshold = st.slider("Flag PF below", 0.50, 0.95, 0.80, 0.01)
flagged = dff[dff["power_factor"] < threshold][["timestamp","voltage_V","current_A","active_power_W","reactive_power_var","power_factor","pf_class"]]
st.dataframe(flagged.sort_values("timestamp").tail(100), use_container_width=True)
st.download_button("Download filtered data as CSV", dff.to_csv(index=False).encode("utf-8"), "filtered_power_factor_data.csv", "text/csv")
